package com.pennant.commands;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.beans.EmployeeDetails;
import com.pennant.dao.EmployeeDAO;
import com.pennant.dao.EmployeeOperations;

public class UpdateEmployeeDetails implements Commands{

	static String fname = null;
	static String lname = null;
	static String des = null;
	static String mob = null;
	static String add = null;
	static String mail = null;
	static String password = null;

	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		
		try {
			doPost(request, response);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
		int updateId = Integer.parseInt(request.getParameter("id"));

		EmployeeDAO dao;
		try {
			dao = new EmployeeOperations();

			fname = request.getParameter("FirstName");
			lname = request.getParameter("LastName");
			des = request.getParameter("design");
			mob = request.getParameter("mobile");
			add = request.getParameter("address");
			mail = request.getParameter("mail");
			password = request.getParameter("pass");

			EmployeeDetails emp = new EmployeeDetails();
			emp.setId(updateId);
			emp.setF_Name(fname);
			emp.setL_Name(lname);
			emp.setDesignation(des);
			emp.setMobile(mob);
			emp.setAddress(add);
			emp.setMail_id(mail);
			emp.setPassword(password);

			int updateDetails = dao.updateDetails(emp, updateId);

			if (updateDetails > 0) {

				response.sendRedirect("EmployeeRetrieve");
			} else {

				response.sendRedirect("updateEmployeeId.jsp");
			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
