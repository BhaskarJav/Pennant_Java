package com.pennant.commands;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.dao.EmployeeDAO;
import com.pennant.dao.EmployeeOperations;

public class DeleteServleteEmployee implements Commands {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("ytfvytfufu");
		doPost(request, response);
		

	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

		int updateId = Integer.parseInt(request.getParameter("Preperence"));
		System.out.println(updateId);
		try {
			EmployeeDAO dao = new EmployeeOperations();

			int deleteEmployee = dao.deleteEmployee(updateId);

			if (deleteEmployee > 0) {
				System.out.println("Deleted");
				response.sendRedirect("RetrieveDetails");
			} else {

				response.sendRedirect("Deletejsp.jsp");
			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
