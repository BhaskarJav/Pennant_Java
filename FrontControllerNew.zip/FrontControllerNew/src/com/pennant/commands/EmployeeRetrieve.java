package com.pennant.commands;

import java.io.IOException;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.dao.EmployeeDAO;
import com.pennant.dao.EmployeeOperations;


public class EmployeeRetrieve implements Commands {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doPost(request, response);

	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		try {
			EmployeeDAO dao = new EmployeeOperations();

			ResultSet rs = dao.displayAllEmployees();

			request.setAttribute("details", rs);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/retrievedetails.jsp");

			dispatcher.forward(request, response);

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
