package com.pennant.commands;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.dao.EmployeeDAO;
import com.pennant.dao.EmployeeOperations;

public class UpdateEmployee implements Commands {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		try {
			doPost(request, response);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

		EmployeeDAO dao;

		try {
			dao = new EmployeeOperations();

			ResultSet rs = dao.updateEmployee();

			request.setAttribute("details", rs);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/UpdateEmployee.jsp");
			try {
				dispatcher.forward(request, response);
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
