package com.pennant.commands;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.dao.EmployeeDAO;
import com.pennant.dao.EmployeeOperations;

public class DeleteServlet implements Commands{

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	doPost(request, response);
		
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		// TODO Auto-generated method stub
		

EmployeeDAO dao;
		
		try {
			try {
				dao = new EmployeeOperations();
				ResultSet rs = dao.deleteEmplyee();

				request.setAttribute("id", rs);
				RequestDispatcher dispatcher = request.getRequestDispatcher("/Deletejsp.jsp");
				dispatcher.forward(request, response);
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			
		
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 

	}
		
		
	}

