package com.pennant.commands;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.beans.EmployeeDetails;
import com.pennant.dao.EmployeeDAO;
import com.pennant.dao.EmployeeOperations;


public class EmployeeLoginSer implements Commands{

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request, response);
		
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) {


		String mail = request.getParameter("mail");
		System.out.println(mail);
		String password = request.getParameter("Password");
		System.out.println(password);

		EmployeeDetails emp=new EmployeeDetails();
		emp.setMail_id(mail);
		emp.setPassword(password);
		
		EmployeeDAO dao;
		try {
			dao = new EmployeeOperations();
			
			if(dao.checkValidUser(mail, password)){
				try {
					response.sendRedirect("EmployeeHome.jsp");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else{
				
				try {
					response.sendRedirect("EmployeeLogin.html");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		
	}

}
