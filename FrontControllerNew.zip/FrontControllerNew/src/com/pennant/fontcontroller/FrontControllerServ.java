 package com.pennant.fontcontroller;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.commands.Commands;
import com.pennant.commands.DeleteServlet;
import com.pennant.commands.DeleteServleteEmployee;
import com.pennant.commands.EmployeeLoginSer;
import com.pennant.commands.EmployeeRetrieve;
import com.pennant.commands.InsertEmployeeDetails;
import com.pennant.commands.UpdateDetailsById;
import com.pennant.commands.UpdateEmployee;
import com.pennant.commands.UpdateEmployeeDetails;




@WebServlet("/FrontControllerServ")
public class FrontControllerServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public FrontControllerServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doPost(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		HashMap<String, Commands> map=new HashMap<>();
		map.put("InsertEmployee", new InsertEmployeeDetails());
		map.put("login", new EmployeeLoginSer());
		map.put("EmployeeRetrieve", new EmployeeRetrieve());
		map.put("UpdateEmployee", new UpdateEmployee());
		map.put("UpdateById", new UpdateDetailsById());
		map.put("UpdateDetails", new UpdateEmployeeDetails());
		map.put("DeleteServlet", new DeleteServlet());
		map.put("DeleteEmployee", new DeleteServleteEmployee());
		
		
		String url = request.getParameter("url");
		System.out.println("hello"+url);
		Commands commands = map.get(url);
		commands.doGet(request, response);
		
		
	}

}
