package com.pennant.connnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

	public static Connection getConnection() throws SQLException, ClassNotFoundException {

		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@pennantsrv13-03:1521:orcl";
		String username = "DB338";
		String password = "pass123";

		Class.forName(driver);
		Connection conn = DriverManager.getConnection(url, username, password);

		return conn;
	}

}
