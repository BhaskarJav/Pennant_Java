package com.pennant.dao;

import java.sql.ResultSet;
import java.util.List;

import com.pennant.beans.EmployeeDetails;

public interface EmployeeDAO {
	public abstract int insertEmployee(EmployeeDetails emp);
	public abstract ResultSet displayAllEmployees();
	public abstract ResultSet updateEmployee();
	public abstract ResultSet updateEmployeeId(int id);
	public abstract int updateDetails(EmployeeDetails emp,int id);
	public abstract int deleteEmployee(int id);
	public abstract ResultSet deleteEmplyee();
	public abstract boolean checkValidUser(String mail, String password);
}
