package com.pennant.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.pennant.beans.EmployeeDetails;
import com.pennant.connnection.DatabaseConnection;

public class EmployeeOperations implements EmployeeDAO {

	Connection conn = null;
	PreparedStatement ps = null;

	public EmployeeOperations() throws ClassNotFoundException, SQLException {

		conn = DatabaseConnection.getConnection();

	}

	@Override
	public int insertEmployee(EmployeeDetails emp) {
		int update = 0;
		try {
			ps = conn.prepareStatement("insert into EmployeeMVC values(?,?,?,?,?,?,?,?)");
			ps.setInt(1, emp.getId());
			ps.setString(2, emp.getF_Name());
			ps.setString(3, emp.getL_Name());
			ps.setString(4, emp.getDesignation());
			ps.setString(5, emp.getMobile());
			ps.setString(6, emp.getAddress());
			ps.setString(7, emp.getMail_id());
			ps.setString(8, emp.getPassword());

			update = ps.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return update;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResultSet displayAllEmployees() {
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement("select * from EmployeeMVC");
			rs = ps.executeQuery();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return rs;
	}

	public ResultSet updateEmployee() {
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement("select * from EmployeeMVC");

			rs = ps.executeQuery();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
	}

	@Override
	public ResultSet updateEmployeeId(int id) {
		ResultSet row = null;
		try {

			ps = conn.prepareStatement("select * from EmployeeMVC where id=?");
			ps.setInt(1, id);
			row = ps.executeQuery();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return row;
	}

	@Override
	public int deleteEmployee(int id) {

		int row = 0;
		try {
			ps = conn.prepareStatement("delete from EmployeeMVC where id=?");
			ps.setInt(1, id);
			row = ps.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return row;
	}

	@Override
	public boolean checkValidUser(String mail, String password) {

		boolean execute = false;

		try {
			ps = conn.prepareStatement("select Mail_id,password from EmployeeMVC where Mail_id=? and password=?");

			ps.setString(1, mail);
			ps.setString(2, password);

		ResultSet rs = ps.executeQuery();
		while(rs.next()){
			
			if(rs.getString(1).equalsIgnoreCase(mail)&& rs.getString(2).equalsIgnoreCase(password)){
				execute=true;
				break;
			}
		}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return execute;

	}

	@Override
	public int updateDetails(EmployeeDetails emp, int id) {
		int update = 0;
		try {
			ps = conn.prepareStatement(
					"update EmployeeMVC set F_Name=?,L_Name=?,Designation=?,Mobile=?,Address=?,Mail_id=?,password=? where id=?");
			System.out.println("segesrghre");

			ps.setString(1, emp.getF_Name());
			ps.setString(2, emp.getL_Name());
			ps.setString(3, emp.getDesignation());
			ps.setString(4, emp.getMobile());
			ps.setString(5, emp.getAddress());
			ps.setString(6, emp.getMail_id());
			ps.setString(7, emp.getPassword());
			ps.setInt(8, id);

			update = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return update;
	}
	@Override
	public ResultSet deleteEmplyee() {
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement("select * from EmployeeMVC");

			rs = ps.executeQuery();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;

	}

}
