package com.pennant.beans;

public class EmployeeDetails {

	private int id;
	private String F_Name;
	private String L_Name;
	private String Designation;
	private String Mobile;
	private String Address;
	private String Mail_id;
	private String password;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getF_Name() {
		return F_Name;
	}

	public void setF_Name(String f_Name) {
		F_Name = f_Name;
	}

	public String getL_Name() {
		return L_Name;
	}

	public void setL_Name(String l_Name) {
		L_Name = l_Name;
	}

	public String getDesignation() {
		return Designation;
	}

	public void setDesignation(String designation) {
		Designation = designation;
	}

	public String getMobile() {
		return Mobile;
	}

	public void setMobile(String mobile) {
		Mobile = mobile;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getMail_id() {
		return Mail_id;
	}

	public void setMail_id(String mail_id) {
		Mail_id = mail_id;
	}

	@Override
	public String toString() {
		return "EmployeeDetails [id=" + id + ", F_Name=" + F_Name + ", L_Name=" + L_Name + ", Designation="
				+ Designation + ", Mobile=" + Mobile + ", Address=" + Address + ", Mail_id=" + Mail_id + ", password="
				+ password + "]";
	}

	public EmployeeDetails(int id, String f_Name, String l_Name, String designation, String mobile, String address,
			String mail_id, String password) {
		super();
		this.id = id;
		F_Name = f_Name;
		L_Name = l_Name;
		Designation = designation;
		Mobile = mobile;
		Address = address;
		Mail_id = mail_id;
		this.password = password;
	}

	public EmployeeDetails() {
		// TODO Auto-generated constructor stub
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
