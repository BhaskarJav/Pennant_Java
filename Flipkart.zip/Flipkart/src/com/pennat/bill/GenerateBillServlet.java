package com.pennat.bill;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.StringTokenizer;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.jasper.tagplugins.jstl.core.ForEach;

import com.pennant.database.DatabaseConnection;

/**
 * Servlet implementation class GenerateBillServlet
 */
@WebServlet("/GenerateBillServlet")
@MultipartConfig
public class GenerateBillServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public GenerateBillServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	static Connection conn = null;

	public void init(ServletConfig config) throws ServletException {
		try {
			conn = DatabaseConnection.getConnection();

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void destroy() {
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();

		Enumeration<String> attributeNames = session.getAttributeNames();

		String element = null;
		int count=0;
		int i=0;
		while (attributeNames.hasMoreElements()) {
			element = attributeNames.nextElement();
			System.out.println(session.getAttribute(element));
			String productdetails = (String) session.getAttribute(element);
			
			
			String[] split = productdetails.split(" ", 2);
		
			int values = Integer.parseInt(split[1]);
			//System.out.println(split[1]);
			count=count+values;
			i++;
		}
		System.out.println(count);
		
		
		session.setAttribute("Bill", count);
		//request.setAttribute("Bill", count);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/FinalBill.jsp");
		dispatcher.forward(request, response);
		

	}
}
