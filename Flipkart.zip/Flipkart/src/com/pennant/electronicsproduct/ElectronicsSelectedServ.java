package com.pennant.electronicsproduct;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pennant.database.DatabaseConnection;

/**
 * Servlet implementation class ElectronicsSelectedServ
 */
@WebServlet("/ElectronicsSelectedServ")
public class ElectronicsSelectedServ extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ElectronicsSelectedServ() {
		super();
		// TODO Auto-generated constructor stub
	}

	static Connection conn = null;
	static PreparedStatement ps = null;

	public void init(ServletConfig config) throws ServletException {
		try {
			conn = DatabaseConnection.getConnection();

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void destroy() {
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		String[] selectedProd = request.getParameterValues("products");
		
		int i=1;
		for (String string : selectedProd) {
			//System.out.println(string);
			session.setAttribute("ElecSelected"+i, string);
			i++;
		}
		
	
		response.sendRedirect("Home.jsp");
		

	}

}
