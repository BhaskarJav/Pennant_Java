package com.pennant.electronicsproduct;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.pennant.database.DatabaseConnection;

/**
 * Servlet implementation class ProductsInsertSer
 */
@WebServlet("/ProductsInsertSer")
@MultipartConfig
public class ProductsInsertSer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductsInsertSer() {
        super();
        // TODO Auto-generated constructor stub
    }

    static Connection conn = null;
	static PreparedStatement ps = null;
	static int id;
	static String name = null;
	static String qua = null;
	static String price = null;
	static String forcate = null;
	
	

	public void init(ServletConfig config) throws ServletException {
		try {
			conn = DatabaseConnection.getConnection();

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void destroy() {
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {

			 id = Integer.parseInt(request.getParameter("id1"));
		
			name = request.getParameter("name");
	
			qua = request.getParameter("quant");
			price = request.getParameter("cost");
			forcate = request.getParameter("forienid");
			Part file = request.getPart("ima");

			ps = conn.prepareStatement("insert into ProductsInfo values(?,?,?,?,?,?)");

			ps.setInt(1, id);
			ps.setString(2, name);
			ps.setString(3, qua);
			ps.setString(4, price);
			ps.setString(5, forcate);
			ps.setBinaryStream(6, file.getInputStream(),(int)file.getSize());

			int update = ps.executeUpdate();

			if (update > 0) {

				response.sendRedirect("Home.jsp");
			} else {

				response.sendRedirect("InsertEmployee.jsp");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
