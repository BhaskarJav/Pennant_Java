package com.pennant.customer;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.database.DatabaseConnection;



@WebServlet("/CustomerLogin")
public class CustomerLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public CustomerLogin() {
		super();
		// TODO Auto-generated constructor stub
	}

	static Connection conn = null;
	static Statement stmt = null;
	static String usname = null;
	static String upass = null;

	public void init(ServletConfig config) throws ServletException {
		try {
			conn = DatabaseConnection.getConnection();

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void destroy() {
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

		doPost(request, response);

	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			stmt = conn.createStatement();

			usname = request.getParameter("name");
			System.out.println(usname);
			upass = request.getParameter("Password");
			System.out.println(upass);

			ResultSet rs = stmt.executeQuery(
					"select * from " + " Customer where Cus_name = '" + usname + "' and password = '" + upass + "'");
			if (rs.next()) {			

				response.sendRedirect("Home.jsp");

			} else {
				response.sendRedirect("Login.html");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
	