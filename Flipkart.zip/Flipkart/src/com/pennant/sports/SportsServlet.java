package com.pennant.sports;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.database.DatabaseConnection;

/**
 * Servlet implementation class SportsServlet
 */
@WebServlet("/SportsServlet")
@MultipartConfig
public class SportsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SportsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    static Connection conn = null;
  	static PreparedStatement ps = null;
    

	public void init(ServletConfig config) throws ServletException {
		try {
			conn = DatabaseConnection.getConnection();

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void destroy() {
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


    protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {

			

			ps = conn.prepareStatement("select * from ProductsInfo where id=?");
			ps.setInt(1, 103);
			
			ResultSet rs = ps.executeQuery();	
			
			
				
				request.setAttribute("products", rs);
				RequestDispatcher dispatcher = request.getRequestDispatcher("/RetrieveSportsProducts.jsp");
				dispatcher.forward(request, response);
			

			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
