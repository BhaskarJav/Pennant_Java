package com.pennant.homeproducts;

import java.io.IOException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.database.DatabaseConnection;

/**
 * Servlet implementation class ProductRetrieve
 */
@WebServlet("/ProductRetrieve")
@MultipartConfig
public class ProductRetrieve extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ProductRetrieve() {
		super();
		// TODO Auto-generated constructor stub
	}

	static Connection conn = null;
	static PreparedStatement ps = null;

	public void init(ServletConfig config) throws ServletException {
		try {
			conn = DatabaseConnection.getConnection();

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void destroy() {
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {

			int pic = Integer.parseInt(request.getParameter("number"));
			ps = conn.prepareStatement("select Image from ProductsInfo where id=?");
			ps.setInt(1, 102);

			ResultSet rs = ps.executeQuery();

			int i = 0;
			while (rs.next()) {
				i++;
				if (pic == i) {

					Blob blob = rs.getBlob("Image");
					byte[] bytes = blob.getBytes(1, (int) blob.length());
					response.setContentType("image/jpg");
					ServletOutputStream os = response.getOutputStream();
					os.write(bytes);
					os.close();
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
