package com.farmerswebmarketing.interfaces;

import java.util.List;

import com.farmerswebmarketing.beans.DriverBean;

public interface DriverDao {
	public List<DriverBean>  getDriverDetails();

}
