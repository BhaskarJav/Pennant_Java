package com.farmerswebmarketing.interfaces;

import com.farmerswebmarketing.beans.FarmerBean;

public interface FarmerDao {

	/*public int addProduct(ProductsBean pb);

	public int removeProduct(ProductsBean pb, int id);

	public int updateProduct(ProductsBean pb, int id);

	public List<ProductsBean> getAllProducts();

	public void getPhotoById(int id, HttpServletResponse response, HttpServletRequest request);
	*/
	public boolean checkValidFarmer(int farmerId,String Password);

	public int insertFarmer(FarmerBean fb);

}
