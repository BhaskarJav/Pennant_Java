package com.farmerswebmarketing.interfaces;

import java.sql.SQLException;

import javax.servlet.ServletException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface Command {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, java.io.IOException;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException, ClassNotFoundException, SQLException;
}
