package com.farmerswebmarketing.interfaces;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.farmerswebmarketing.beans.ProductsBean;

public interface VisitorDao {
	List<ProductsBean> getProductDitails();

	public void getPhotoById(int id, HttpServletResponse response, HttpServletRequest request);
}
