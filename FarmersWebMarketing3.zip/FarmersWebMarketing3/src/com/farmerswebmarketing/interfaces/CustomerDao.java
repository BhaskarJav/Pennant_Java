package com.farmerswebmarketing.interfaces;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.farmerswebmarketing.beans.CustomerBean;
import com.farmerswebmarketing.beans.ProductsBean;

public interface CustomerDao {
	
	public abstract List<ProductsBean> allProducts(int farmerSeleId);
	
	public boolean checkValidUser(int id, String pwd, HttpServletRequest request);

	public int insertCustomer(CustomerBean cust);

}
