package com.farmerswebmarketing.interfaces;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.farmerswebmarketing.beans.ProductsBean;

public interface ProductDao {


		public int addProduct(ProductsBean pb);

		public int removeProduct(int id);

		public ProductsBean updateProduct(ProductsBean pb, int id);
		public int updateProducts(ProductsBean pb, int id);

		public List<ProductsBean> getAllProducts();
		
		public void	 getPhotoById(int id, HttpServletResponse response, HttpServletRequest request);
	}
