package com.farmerswebmarketing.interfaces;

import java.util.List;

import com.farmerswebmarketing.beans.FarmerBean;

public interface AdminDao {

	public abstract boolean checkValidAdmin(String username, String password);

	public abstract List<FarmerBean> getFarmerDetails();

	public abstract int deleteFarmerById(int id);
}
