package com.farmerswebmarketing.customercommands;

import java.io.IOException;

import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.farmerswebmarketing.beans.DriverBean;
import com.farmerswebmarketing.daos.DriverImplClass;
import com.farmerswebmarketing.interfaces.Command;
import com.farmerswebmarketing.interfaces.DriverDao;

public class DriverClass implements Command {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		DriverDao dic = new DriverImplClass();
		try {
			List<DriverBean> driverDetails = dic.getDriverDetails();

			request.setAttribute("driverlist", driverDetails);
			RequestDispatcher rd = request.getRequestDispatcher("driverDetails.jsp");

			rd.forward(request, response);
		} catch (ServletException e) {
			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

}
