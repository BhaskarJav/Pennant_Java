package com.farmerswebmarketing.customercommands;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.farmerswebmarketing.beans.ProductsBean;
import com.farmerswebmarketing.interfaces.Command;

public class ProductsBill implements Command {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);

	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		HttpSession session = request.getSession();
		List<ProductsBean> list = new ArrayList<ProductsBean>();
		Enumeration<String> attributeNames = session.getAttributeNames();

		String element = null;
		int id = 0;
		double count = 0;
		double price = 0;
		int quantity = 0;
		int farId ;
		int i = 0;
		String[] prods = new String[100];
		while (attributeNames.hasMoreElements()) {
			element = attributeNames.nextElement();
			System.out.println(session.getAttribute(element));

			prods[i] = (String) session.getAttribute(element);

			String[] split = prods[i].split(" ", 5);
			id = Integer.parseInt((split[0]));
			System.out.println(id);

		
			
			price = Double.parseDouble((split[2]));
			System.out.println(price);
			quantity = Integer.parseInt((split[3]));
			System.out.println(quantity);
			count = count+(quantity * price);
			
			
			ProductsBean productsBean = new ProductsBean();
			productsBean.setProduct_id(id);
			productsBean.setProduct_name(split[1]);
			productsBean.setPrice(price);
			productsBean.setQuantity(quantity);
			
			farId = Integer.parseInt((split[4]));
			productsBean.setFarmer_id(farId);
			list.add(productsBean);

			session.setAttribute("list", list);
			i++;
		}
		System.out.println(count);

		session.setAttribute("Bill", count);


		RequestDispatcher dispatcher = request.getRequestDispatcher("FinalBill.jsp?i=" + i);
		dispatcher.forward(request, response);

	}

}
