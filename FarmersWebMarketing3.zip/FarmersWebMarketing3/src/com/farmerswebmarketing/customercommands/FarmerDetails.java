package com.farmerswebmarketing.customercommands;

import java.io.IOException;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.farmerswebmarketing.beans.FarmerBean;
import com.farmerswebmarketing.daos.AdminOperations;
import com.farmerswebmarketing.interfaces.AdminDao;
import com.farmerswebmarketing.interfaces.Command;

public class FarmerDetails implements Command{

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
		
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

		@SuppressWarnings("unused")
		FarmerBean farmerBean = new FarmerBean();

		try {
			AdminDao dao=new AdminOperations();
			System.out.println("wregyrewhh");
			List<FarmerBean> farmerDetails = dao.getFarmerDetails();
			System.out.println("gvwgwg");
			
			request.setAttribute("details", farmerDetails);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/FarmerRetrieveforCust.jsp");

			dispatcher.forward(request, response);
			
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		
		
		
	}

