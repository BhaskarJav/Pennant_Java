package com.farmerswebmarketing.customercommands;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.farmerswebmarketing.interfaces.Command;

public class ProductsSession implements Command{

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	doPost(request, response);
		
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		HttpSession session = request.getSession();
		String[] selectedProd = request.getParameterValues("products");
		
		int i=1;
		for (String string : selectedProd) {
			System.out.println(string);
			session.setAttribute("ProdSelected"+i, string);
			i++;
		}
		
		
		response.sendRedirect("FrontController?url=ProductsForBill");
		
		
	}

}
