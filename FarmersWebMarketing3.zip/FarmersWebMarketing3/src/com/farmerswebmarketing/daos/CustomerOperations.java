package com.farmerswebmarketing.daos;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.farmerswebmarketing.beans.CustomerBean;
import com.farmerswebmarketing.beans.ProductsBean;
import com.farmerswebmarketing.interfaces.CustomerDao;
import com.farmerswebmarketing.mappers.CustomerRowMapper;
import com.farmerswebmarketing.mappers.RowMapperProduct;

public class CustomerOperations implements CustomerDao{
	JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	public CustomerOperations() throws ClassNotFoundException, SQLException {
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"com/farmerswebmarketing/config/applicationContext.xml");
		template = context.getBean("jdbcTemplate", JdbcTemplate.class);
		
	}


	@Override
	public List<ProductsBean> allProducts(int id) {


		String sql="select * from products_table where farmer_id=?";
		
		List<ProductsBean> products = template.query(sql, new RowMapperProduct(), id );
		
		return products;
	}


	
	@Override
	public boolean checkValidUser(int id, String pwd, HttpServletRequest request) {
		boolean flag = false;
		String query = "select customer_Id,customer_name,customer_password from customer_table where customer_id=?";
		System.out.println(id);
		System.out.println(pwd);
		CustomerRowMapper customerRowMapper = new CustomerRowMapper();
		CustomerBean cb = template.queryForObject(query, customerRowMapper, id);
		System.out.println(cb.getCustomer_id());
		System.out.println(cb.getCustomer_name());
		if (cb.getCustomer_id() == id && cb.getCustomer_password().equals(pwd)) {
			String customer_name = cb.getCustomer_name();
			System.out.println(cb.getCustomer_id());
			System.out.println(cb.getCustomer_name());
			System.out.println(pwd);
			flag = true;
		} else {
			flag = false;
		}

		return flag;
	}

	@Override
	public int insertCustomer(CustomerBean cust) {
		int insert = 0;
		String query = "insert into customer_table values(?,?,?,?,?,?,?,?,?,?)";
		insert = template.update(query, cust.getCustomer_id(), cust.getCustomer_name(), cust.getCustomer_phone_no(),
				cust.getHouse_no(), cust.getVillage(), cust.getMandal(), cust.getDistrict(), cust.getState(),
				cust.getPincode(), cust.getCustomer_password());
		return insert;
	}


}
