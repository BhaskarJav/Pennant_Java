package com.farmerswebmarketing.daos;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.farmerswebmarketing.beans.DriverBean;
import com.farmerswebmarketing.interfaces.DriverDao;
import com.farmerswebmarketing.mappers.RowMapperDriver;

public class DriverImplClass implements DriverDao {
	JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	public DriverImplClass(){
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"com/farmerswebmarketing/config/applicationContext.xml");
		template = context.getBean("jdbcTemplate", JdbcTemplate.class);

	}

	@Override
	public List<DriverBean> getDriverDetails() {
		String sql = "select * from driver";
		
		List<DriverBean> list = template.query(sql, new RowMapperDriver());
		System.out.println(list);
		return list;

	}

}
