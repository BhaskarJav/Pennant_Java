package com.farmerswebmarketing.daos;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import com.farmerswebmarketing.beans.ProductsBean;
import com.farmerswebmarketing.interfaces.ProductDao;
import com.farmerswebmarketing.mappers.RowMapperProduct;

public class ProductOperations implements ProductDao {
	JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	public ProductOperations() throws ClassNotFoundException, SQLException {
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"com/farmerswebmarketing/config/applicationContext.xml");
		template = context.getBean("jdbcTemplate", JdbcTemplate.class);
		
	}

	@Override
	public int addProduct(ProductsBean pb) {

		String sql = "insert into products_table values(?,?,?,?,?,?)";
		/*
		 * update = template.update(sql, pb.getProduct_id(),
		 * pb.getProduct_name(), pb.getQuantity(), pb.getPrice(),
		 * pb.getProduct_image(), pb.getFarmer_id());
		 */

		return template.execute(sql, new PreparedStatementCallback<Integer>() {

			@Override
			public Integer doInPreparedStatement(PreparedStatement pst) throws SQLException, DataAccessException {

				pst.setInt(1, pb.getProduct_id());
				pst.setString(2, pb.getProduct_name());
				pst.setInt(3, pb.getQuantity());
				pst.setDouble(4, pb.getPrice());

				try {
					pst.setBinaryStream(5, pb.getProduct_image().getInputStream(),
							(int) pb.getProduct_image().getSize());
					System.out.println(pb.getProduct_image());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				pst.setInt(6, pb.getFarmer_id());

				int executeUpdate = pst.executeUpdate();
				return executeUpdate;
			}
		});

	}

	@Override
	public int removeProduct(int id) {

		String sql = "delete products_table where product_id=?";


		int update = template.update(sql, id);

		return update;
	}

	@Override
	public ProductsBean updateProduct(ProductsBean pb, int id) {


		System.out.println(id);

		String sql = "select * from products_table where product_id=?";

		ProductsBean productDetails = (ProductsBean) template.queryForObject(sql, new Object[] { id },
				new RowMapperProduct());

		return productDetails;
		
		
	}

	@Override
	public List<ProductsBean> getAllProducts() {

		String sql = "select * from products_table";

		List<ProductsBean> list = template.query(sql, new RowMapperProduct());

		return list;

	}

	@Override
	public void getPhotoById(int id, HttpServletResponse response, HttpServletRequest request) {
		// TODO Auto-generated method stub
		String query = "select product_image from products_table where product_id="+id;
		
		Blob b = null;
		byte[] imgData = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@pennantsrv13-03:1521:orcl","DB358","pass123");
			
			Statement cs = con.createStatement();
			ResultSet rs = cs.executeQuery(query);
			rs.next();
			b = rs.getBlob(1);
			imgData = b.getBytes(1, (int) b.length());

			response.setContentType("image/jpeg");
			response.setContentLength((int) b.length());
			InputStream is = b.getBinaryStream();

			OutputStream os = response.getOutputStream();
			is.read(imgData);
			os.write(imgData);
			os.close();
			rs.close();
		} catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public int updateProducts(ProductsBean pb, int id) {
		
		
		int update = 0;

		String sql = "update products_table set product_name=?,quantity=?,price=?,farmer_id=? where product_id=?";

		update = template.update(sql, pb.getProduct_name(),pb.getQuantity(),pb.getPrice(),pb.getFarmer_id(),pb.getProduct_id());

		return update;
		
			
	}

}
