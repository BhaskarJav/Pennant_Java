package com.farmerswebmarketing.daos;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.RowMapper;

import com.farmerswebmarketing.beans.AdminBean;
import com.farmerswebmarketing.beans.FarmerBean;
import com.farmerswebmarketing.beans.ProductsBean;
import com.farmerswebmarketing.interfaces.FarmerDao;
import com.farmerswebmarketing.mappers.FarmerRowMapper;
import com.farmerswebmarketing.mappers.ProductsRowMapper;
import com.farmerswebmarketing.mappers.RowMapperAdmin;

public class FarmerDaoImpl implements FarmerDao {
	JdbcTemplate jdbcTemplate;
	ApplicationContext container = new ClassPathXmlApplicationContext("com/farmerswebmarketing/config/applicationContext.xml");

	public FarmerDaoImpl() {
		jdbcTemplate = container.getBean(JdbcTemplate.class);
	}

	/*@Override
	public int addProduct(ProductsBean pb) {
		Integer insert = 0;
		String sql = "insert into products_table values(?,?,?,?,?,?)";
		System.out.println("pid: " + pb.getProduct_id() + ", pname: " + pb.getProduct_name() + ", qnty: "
				+ pb.getQuantity() + ", price: " + pb.getPrice());
		insert = jdbcTemplate.execute(sql, new PreparedStatementCallback<Integer>() {

			@Override
			public Integer doInPreparedStatement(PreparedStatement pst) throws SQLException, DataAccessException {
				pst.setInt(1, pb.getProduct_id());
				pst.setString(2, pb.getProduct_name());
				pst.setInt(3, pb.getQuantity());
				pst.setDouble(4, pb.getPrice());
				try {
					pst.setBinaryStream(5, pb.getProduct_image().getInputStream(),
							(int) pb.getProduct_image().getSize());
				} catch (IOException e) {
					e.printStackTrace();
				}
				pst.setInt(6, pb.getFarmer_id());
				return pst.executeUpdate();
			}
		});
		return insert;
	}

	@Override
	public int removeProduct(ProductsBean pb, int id) {
		return 0;
	}

	@Override
	public int updateProduct(ProductsBean pb, int id) {
		String sql = "update products_table set product_name=?,quantity=?,price=? where product_id=?";
		int update = jdbcTemplate.update(sql, pb.getProduct_name(), pb.getQuantity(), pb.getPrice(),
				pb.getProduct_id());
		return update;
	}

	@Override
	public List<ProductsBean> getAllProducts() {
		String query = "select * from products_table";
		List<ProductsBean> list = jdbcTemplate.query(query, new ProductsRowMapper());

		return list;
	}

	@Override
	public void getPhotoById(int id, HttpServletResponse response, HttpServletRequest request) {
		String query = "select product_image from products_table where product_id=" + id;
		Blob b = null;
		byte[] imgData = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@pennantsrv13-03:1521:orcl", "DB336",
					"pass123");

			Statement cs = con.createStatement();
			ResultSet rs = cs.executeQuery(query);
			if (rs.next() && rs != null) {
				b = rs.getBlob(1);
				imgData = b.getBytes(1, (int) b.length());

				response.setContentType("image/jpeg");
				response.setContentLength((int) b.length());
				InputStream is = b.getBinaryStream();

				OutputStream os = response.getOutputStream();
				is.read(imgData);
				os.write(imgData);
				os.close();
				rs.close();
			}
		} catch (SQLException | IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public List<ProductsBean> getProductById(int id) {
		String sql = "select * from products_table where product_id=" + id;

		return jdbcTemplate.query(sql, new RowMapper<ProductsBean>() {

			@Override
			public ProductsBean mapRow(ResultSet rs, int id) throws SQLException {
				ProductsBean bean = new ProductsBean();
				bean.setProduct_id(rs.getInt("product_id"));
				bean.setProduct_name(rs.getString("product_name"));
				bean.setQuantity(rs.getInt("quantity"));
				bean.setPrice(rs.getInt("price"));
				return bean;
			}

		});

	}*/

	@Override
	public boolean checkValidFarmer(int farmerId, String Password) {
	
		boolean execute = false;
		String sql = "select farmer_id,farmer_password from Farmer_table1 where farmer_id=? and farmer_password=?";
		
		FarmerRowMapper row=new FarmerRowMapper();
		
		FarmerBean details = jdbcTemplate.queryForObject(sql,row, farmerId, Password);

		if (Password.equalsIgnoreCase(details.getFarmer_password())) {

			execute = true;

		}else{
			execute=false;
		}
		return execute;
	}

	@Override
	public int insertFarmer(FarmerBean fb) {

		String sql = "Insert into Farmer_table1 values(?,?,?,?,?,?,?,?,?,?)";
		int res = jdbcTemplate.update(sql, fb.getFarmer_id(), fb.getFarmer_name(), fb.getFarmer_phone_no(),
				fb.getHouse_no(), fb.getVillage(), fb.getMandal(), fb.getDistrict(), fb.getState(), fb.getPincode(),
				fb.getFarmer_password());
		System.out.println(res + "hello");

		return res;
	}

}
