package com.farmerswebmarketing.daos;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.farmerswebmarketing.beans.AdminBean;
import com.farmerswebmarketing.beans.FarmerBean;
import com.farmerswebmarketing.interfaces.AdminDao;
import com.farmerswebmarketing.mappers.RowMapperAdmin;

public class AdminOperations implements AdminDao {

	JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	public AdminOperations() throws ClassNotFoundException, SQLException {
		@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"com/farmerswebmarketing/config/applicationContext.xml");
		template = context.getBean("jdbcTemplate", JdbcTemplate.class);

	}

	@Override
	public boolean checkValidAdmin(String username, String password) {

		boolean execute = false;

		String sql = "select username,password from Admin_table where username=? and password=?";
		RowMapperAdmin row = new RowMapperAdmin();

		AdminBean details = template.queryForObject(sql, row, username, password);

		if (username.equalsIgnoreCase(details.getUsername()) && password.equalsIgnoreCase(details.getPassword())) {

			execute = true;

		}

		return execute;

	}

	@Override
	public List<FarmerBean> getFarmerDetails() {

		System.out.println("Bhaskr");

		String sql = "select * from Farmer_table1";
		List<FarmerBean> farmerDetails = new ArrayList<>();
		List<Map<String, Object>> rows = template.queryForList(sql);

		for (Map<String, Object> map : rows) {

			FarmerBean farmerBean = new FarmerBean();

			System.out.println(map.get("farmer_id"));
			System.out.println(map.get("farmer_name"));

			farmerBean.setFarmer_id(Integer.parseInt(map.get("farmer_id").toString()));
			System.out.println(map.get("farmer_id"));
			farmerBean.setFarmer_name((String) map.get("farmer_name"));
			farmerBean.setFarmer_phone_no(Long.parseLong(map.get("phone_no").toString()));
			System.out.println(map.get("phone_no"));
			farmerBean.setHouse_no((String) map.get("house_no"));
			farmerBean.setVillage((String) map.get("village"));
			farmerBean.setMandal((String) map.get("mandal"));
			farmerBean.setDistrict((String) map.get("district"));
			farmerBean.setState((String) map.get("state"));

			farmerBean.setPincode(Integer.parseInt(map.get("pincode").toString()));
			farmerBean.setFarmer_password((String) map.get("farmer_password"));
			farmerDetails.add(farmerBean);
			
			

		}
		return farmerDetails;

	}

	@Override
	public int deleteFarmerById(int id) {

		String sql = "delete from Farmer_table1 where farmer_id=?";

		int update = template.update(sql, id);

		return update;

	}

}
