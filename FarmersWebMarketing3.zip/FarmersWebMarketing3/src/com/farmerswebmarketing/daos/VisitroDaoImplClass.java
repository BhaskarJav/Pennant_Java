package com.farmerswebmarketing.daos;

import java.io.IOException;

import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.farmerswebmarketing.beans.ProductsBean;
import com.farmerswebmarketing.interfaces.VisitorDao;
import com.farmerswebmarketing.mappers.RowMapperProduct;

public class VisitroDaoImplClass implements VisitorDao {
	JdbcTemplate jdbcTemplate;
	ApplicationContext ac = new ClassPathXmlApplicationContext("com/farmerswebmarketing/config/applicationContext.xml");

	public VisitroDaoImplClass() {
		jdbcTemplate = ac.getBean("jdbcTemplate", JdbcTemplate.class);
		System.out.println(jdbcTemplate + "helooooooo");
	}

	@Override
	public List<ProductsBean> getProductDitails() {
		String sql = "Select * from products_table";
		List<ProductsBean> list = jdbcTemplate.query(sql, new RowMapperProduct());
		return list;

	}

	@Override
	public void getPhotoById(int id, HttpServletResponse response, HttpServletRequest request) {
		String query = "select product_image from products_table where product_id=" + id;
		Blob b = null;
		byte[] imgData = null;

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");

			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@pennantsrv13-03:1521:orcl", "DB338",
					"pass123");

			Statement createStatement = con.createStatement();
			ResultSet rs = createStatement.executeQuery(query);
			rs.next();
			b = rs.getBlob(1);
			imgData = b.getBytes(1, (int) b.length());

			response.setContentType("image/jpeg");
			response.setContentLength((int) b.length());
			InputStream is = b.getBinaryStream();

			OutputStream os = response.getOutputStream();
			is.read(imgData);
			os.write(imgData);
			os.close();
			rs.close();
		} catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
