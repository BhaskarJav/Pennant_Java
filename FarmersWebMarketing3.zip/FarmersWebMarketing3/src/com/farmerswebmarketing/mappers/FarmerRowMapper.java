package com.farmerswebmarketing.mappers;

import java.sql.ResultSet;

import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.farmerswebmarketing.beans.FarmerBean;

public class FarmerRowMapper implements RowMapper<FarmerBean> {

	@Override
	public FarmerBean mapRow(ResultSet rs, int rowNum) throws SQLException {
	
		FarmerBean farmerBean = new FarmerBean();
		farmerBean.setFarmer_id(rs.getInt("farmer_id"));
		/*farmerBean.setFarmer_name(rs.getString("farmer_name"));
		farmerBean.setFarmer_phone_no(rs.getLong("phone_no"));
		farmerBean.setHouse_no(rs.getString("house_no"));
		farmerBean.setVillage(rs.getString("village"));
		farmerBean.setMandal(rs.getString("mandal"));
		farmerBean.setDistrict((rs.getString("district")));
		farmerBean.setState((rs.getString("state")));
		farmerBean.setPincode(rs.getInt("pincode"));*/
		farmerBean.setFarmer_password(rs.getString("farmer_password"));
		return farmerBean;
	}

}
