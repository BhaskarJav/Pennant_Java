package com.farmerswebmarketing.mappers;
import java.sql.ResultSet;


import java.sql.SQLException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.farmerswebmarketing.beans.DriverBean;

public class RowMapperDriver implements RowMapper<DriverBean> {
	JdbcTemplate jdbcTemplate;

	public RowMapperDriver() {
		ApplicationContext ac = new ClassPathXmlApplicationContext("com/farmerswebmarketing/config/applicationContext.xml");

		jdbcTemplate = ac.getBean("jdbcTemplate", JdbcTemplate.class);
		System.out.println(jdbcTemplate + "helooooooo");
	}
	@Override
	public DriverBean mapRow(ResultSet rs, int arg1) throws SQLException {
		DriverBean driverBean = new DriverBean();

		driverBean.setDriverId(rs.getInt(1));
		System.out.println(rs.getInt(1));
		driverBean.setDriverName(rs.getString(2));
		driverBean.setPhoneNumber(rs.getLong(3));
		driverBean.setVehicleNumber(rs.getString(4));
		driverBean.setVehiclename(rs.getString(5));

		return driverBean;
	}

}
