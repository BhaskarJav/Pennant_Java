package com.farmerswebmarketing.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.farmerswebmarketing.beans.CustomerBean;

public class CustomerRowMapper implements RowMapper<CustomerBean> {

	@Override
	public CustomerBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		CustomerBean customerBean = new CustomerBean();
		customerBean.setCustomer_id(rs.getInt("customer_id"));
		customerBean.setCustomer_name(rs.getString("customer_name"));
		customerBean.setCustomer_password(rs.getString("customer_password"));
		return customerBean;
	}

}
