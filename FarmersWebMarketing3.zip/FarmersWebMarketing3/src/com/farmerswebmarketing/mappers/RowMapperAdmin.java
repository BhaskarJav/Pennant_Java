package com.farmerswebmarketing.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.farmerswebmarketing.beans.AdminBean;

public class RowMapperAdmin implements RowMapper<AdminBean>{
	
	private JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public AdminBean mapRow(ResultSet rs, int arg1) throws SQLException {

		AdminBean adminDetails=new AdminBean();
		
		
		adminDetails.setUsername(rs.getString(1));
		adminDetails.setPassword(rs.getString(2));
		
		return adminDetails;
	}
}