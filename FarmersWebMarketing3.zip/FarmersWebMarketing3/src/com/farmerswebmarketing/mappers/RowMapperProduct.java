package com.farmerswebmarketing.mappers;



import java.sql.ResultSet;

import java.sql.SQLException;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.farmerswebmarketing.beans.ProductsBean;

public class RowMapperProduct implements RowMapper<ProductsBean> {

	private JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public ProductsBean mapRow(ResultSet rs, int arg1) throws SQLException {

		ProductsBean productsBean = new ProductsBean();

		productsBean.setProduct_id(rs.getInt(1));
		productsBean.setProduct_name(rs.getString(2));
		productsBean.setQuantity(rs.getInt(3));
		productsBean.setPrice(rs.getDouble(4));
		
		productsBean.setFarmer_id(rs.getInt(6));
	
		return productsBean;
	}
}
