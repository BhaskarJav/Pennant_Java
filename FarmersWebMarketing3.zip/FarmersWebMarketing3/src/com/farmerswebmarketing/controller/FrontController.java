package com.farmerswebmarketing.controller;

import java.io.IOException;

import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.farmerswebmarketing.commands.AdminLoginCommand;
import com.farmerswebmarketing.commands.CustomerLoginCommand;
import com.farmerswebmarketing.commands.CustomerSignUpCommand;
import com.farmerswebmarketing.commands.VisitorsClass;
import com.farmerswebmarketing.commands.admin.DeleteFarmerById;
import com.farmerswebmarketing.commands.admin.DeleteFarmerDetails;
import com.farmerswebmarketing.commands.admin.RetrieveFarmerDetails;
import com.farmerswebmarketing.commands.farmer.CustomerSelectedItems;
import com.farmerswebmarketing.commands.farmer.FarmerLoginClass;
import com.farmerswebmarketing.commands.farmer.FarmerRegistrtionClass;
import com.farmerswebmarketing.commands.farmer.ProductDelete;
import com.farmerswebmarketing.commands.farmer.ProductDeleteById;
import com.farmerswebmarketing.commands.farmer.ProductUpdate;
import com.farmerswebmarketing.commands.farmer.ProductUpdateById;
import com.farmerswebmarketing.commands.farmer.ProductUpdatedDetails;
import com.farmerswebmarketing.commands.farmer.ProductsInsert;
import com.farmerswebmarketing.commands.farmer.RetrieveProducts;
import com.farmerswebmarketing.commands.farmer.RetrievingImage;
import com.farmerswebmarketing.customercommands.ConfirmOrder;
import com.farmerswebmarketing.customercommands.DriverClass;
import com.farmerswebmarketing.customercommands.FarmerDetails;
import com.farmerswebmarketing.customercommands.ProductsBill;
import com.farmerswebmarketing.customercommands.ProductsRetrieveCustomer;
import com.farmerswebmarketing.customercommands.ProductsSession;
import com.farmerswebmarketing.interfaces.Command;

@WebServlet("/FrontController")
@MultipartConfig
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public FrontController() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HashMap<String, Command> hashMap = new HashMap<String, Command>();
		hashMap.put("customerlogin", new CustomerLoginCommand());
		hashMap.put("customersignup", new CustomerSignUpCommand());

		hashMap.put("adminlogin", new AdminLoginCommand());

		hashMap.put("RetrieveFarmer", new RetrieveFarmerDetails());

		hashMap.put("deleteFarmer", new DeleteFarmerDetails());
		hashMap.put("DeleteFarmerDetailsById", new DeleteFarmerById());
		hashMap.put("farmerssignup", new FarmerRegistrtionClass());
		hashMap.put("farmerlog", new FarmerLoginClass());

		hashMap.put("InsertProduct", new ProductsInsert());
		System.out.println("hjbfbgyui");

		hashMap.put("RetrieveProducts", new RetrieveProducts());
		hashMap.put("ImageRetreive", new RetrievingImage());

		hashMap.put("UpdateProducts", new ProductUpdate());
		hashMap.put("ProductByid", new ProductUpdateById());
		hashMap.put("ProduUpdate", new ProductUpdatedDetails());

		hashMap.put("DeleteProducts", new ProductDelete());
		hashMap.put("ProductDeByid", new ProductDeleteById());

		hashMap.put("RetrieveFar", new FarmerDetails());
		hashMap.put("ProductsRetrieve", new ProductsRetrieveCustomer());

		hashMap.put("ProductsSelected", new ProductsSession());
		hashMap.put("ProductsForBill", new ProductsBill());
		hashMap.put("co", new ConfirmOrder());
		hashMap.put("CustomerSelectedItems", new CustomerSelectedItems());
		hashMap.put("visitor", new VisitorsClass());
		hashMap.put("Driver", new DriverClass());

		String url = request.getParameter("url");
		System.out.println(url);
		Command command = hashMap.get(url);
		command.doGet(request, response);
	}

}
