package com.farmerswebmarketing.beans;

public class FarmerBean {

	private int farmer_id;
	private String farmer_name;
	private long farmer_phone_no;
	private String farmer_password;
	private String house_no;
	private String village;
	private String mandal;
	private String district;
	private String state;
	private int pincode;

	public FarmerBean() {
		super();
	}

	public FarmerBean(int farmer_id, String farmer_name, long farmer_phone_no, String farmer_password, String house_no,
			String village, String mandal, String district, String state, int pincode) {
		super();
		this.farmer_id = farmer_id;
		this.farmer_name = farmer_name;
		this.farmer_phone_no = farmer_phone_no;
		this.farmer_password = farmer_password;
		this.house_no = house_no;
		this.village = village;
		this.mandal = mandal;
		this.district = district;
		this.state = state;
		this.pincode = pincode;
	}

	public int getFarmer_id() {
		return farmer_id;
	}

	public void setFarmer_id(int farmer_id) {
		this.farmer_id = farmer_id;
	}

	public String getFarmer_name() {
		return farmer_name;
	}

	public void setFarmer_name(String farmer_name) {
		this.farmer_name = farmer_name;
	}

	public long getFarmer_phone_no() {
		return farmer_phone_no;
	}

	public void setFarmer_phone_no(long farmer_phone_no) {
		this.farmer_phone_no = farmer_phone_no;
	}

	public String getFarmer_password() {
		return farmer_password;
	}

	public void setFarmer_password(String farmer_password) {
		this.farmer_password = farmer_password;
	}

	public String getHouse_no() {
		return house_no;
	}

	public void setHouse_no(String house_no) {
		this.house_no = house_no;
	}

	public String getMandal() {
		return mandal;
	}

	public void setMandal(String mandal) {
		this.mandal = mandal;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public String getVillage() {
		return village;
	}

	public void setVillage(String village) {
		this.village = village;
	}

}
