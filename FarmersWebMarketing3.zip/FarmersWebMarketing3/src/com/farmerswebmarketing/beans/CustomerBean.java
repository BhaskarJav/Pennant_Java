package com.farmerswebmarketing.beans;

public class CustomerBean {

	private int customer_id;
	private String customer_name;
	private long customer_phone_no;
	private String customer_password;
	private String house_no;
	private String village;
	private String mandal;
	private String district;
	private String state;
	private int pincode;

	public CustomerBean() {
	}


	public CustomerBean(int customer_id, String customer_name, long customer_phone_no, String customer_password,
			String house_no, String village, String mandal, String district, String state, int pincode) {
		super();
		this.customer_id = customer_id;
		this.customer_name = customer_name;
		this.customer_phone_no = customer_phone_no;
		this.customer_password = customer_password;
		this.house_no = house_no;
		this.village = village;
		this.mandal = mandal;
		this.district = district;
		this.state = state;
		this.pincode = pincode;
	}



	public String getHouse_no() {
		return house_no;
	}

	public void setHouse_no(String house_no) {
		this.house_no = house_no;
	}

	public String getMandal() {
		return mandal;
	}

	public void setMandal(String mandal) {
		this.mandal = mandal;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public int getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public long getCustomer_phone_no() {
		return customer_phone_no;
	}

	public void setCustomer_phone_no(long customer_phone_no) {
		this.customer_phone_no = customer_phone_no;
	}

	public String getCustomer_password() {
		return customer_password;
	}

	public void setCustomer_password(String customer_password) {
		this.customer_password = customer_password;
	}

	public String getVillage() {
		return village;
	}

	public void setVillage(String village) {
		this.village = village;
	}

}
