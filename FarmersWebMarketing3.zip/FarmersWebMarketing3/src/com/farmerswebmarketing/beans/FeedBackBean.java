package com.farmerswebmarketing.beans;

public class FeedBackBean {

	private int feedback_id;
	private int farmer_id;
	private int ratings;
	private int customer_id;

	public FeedBackBean() {
	}

	public FeedBackBean(int feedback_id, int farmer_id, int ratings, int customer_id) {
		super();
		this.feedback_id = feedback_id;
		this.farmer_id = farmer_id;
		this.ratings = ratings;
		this.customer_id = customer_id;
	}

	public int getFeedback_id() {
		return feedback_id;
	}

	public void setFeedback_id(int feedback_id) {
		this.feedback_id = feedback_id;
	}

	public int getFarmer_id() {
		return farmer_id;
	}

	public void setFarmer_id(int farmer_id) {
		this.farmer_id = farmer_id;
	}

	public int getRatings() {
		return ratings;
	}

	public void setRatings(int ratings) {
		this.ratings = ratings;
	}

	public int getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}

}
