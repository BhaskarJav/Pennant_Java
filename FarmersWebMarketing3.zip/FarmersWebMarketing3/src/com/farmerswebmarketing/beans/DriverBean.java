package com.farmerswebmarketing.beans;

public class DriverBean {
	private int driverId;
	private String driverName;
	private long phoneNumber;
	private String vehicleNumber;
	private String vehicleName;

	public DriverBean() {
		
	}

	public DriverBean(int driverId, String driverName, long phoneNumber, String vehicleNumber, String vehicleName) {
		super();
		this.driverId = driverId;
		this.driverName = driverName;
		this.phoneNumber = phoneNumber;
		this.vehicleNumber = vehicleNumber;
		this.vehicleName = vehicleName;
	}

	public int getDriverId() {
		return driverId;
	}

	public void setDriverId(int driverId) {
		this.driverId = driverId;
	}

	public String getDriverName() {
		return driverName;
	}

	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getVehicleNumber() {
		return vehicleNumber;
	}

	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}

	public String getVehiclename() {
		return vehicleName;
	}

	public void setVehiclename(String vehicleName) {
		this.vehicleName = vehicleName;
	}

}
