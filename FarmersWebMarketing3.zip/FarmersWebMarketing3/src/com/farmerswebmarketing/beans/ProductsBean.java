package com.farmerswebmarketing.beans;

import javax.servlet.http.Part;

public class ProductsBean {

	private int product_id;
	private String product_name;
	private int quantity;
	private double price;
	private int farmer_id;
	private Part product_image;

	public ProductsBean() {
	}

	public ProductsBean(int product_id, String product_name, int quantity, double price, int farmer_id,
			Part product_image) {
		super();
		this.product_id = product_id;
		this.product_name = product_name;
		this.quantity = quantity;
		this.price = price;
		this.farmer_id = farmer_id;
		this.product_image = product_image;
	}

	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getFarmer_id() {
		return farmer_id;
	}

	public void setFarmer_id(int farmer_id) {
		this.farmer_id = farmer_id;
	}

	public Part getProduct_image() {
		return product_image;
	}

	public void setProduct_image(Part product_image) {
		this.product_image = product_image;
	}

	@Override
	public String toString() {
		return "ProductsBean [product_id=" + product_id + ", product_name=" + product_name + ", quantity=" + quantity
				+ ", price=" + price + ", farmer_id=" + farmer_id + ", product_image=" + product_image + "]";
	}

}
