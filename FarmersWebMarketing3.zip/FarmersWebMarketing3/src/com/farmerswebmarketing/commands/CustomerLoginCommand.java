package com.farmerswebmarketing.commands;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.farmerswebmarketing.daos.CustomerOperations;
import com.farmerswebmarketing.interfaces.Command;

public class CustomerLoginCommand implements Command {

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp) {
		try {
			doPost(req, resp);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException {
		int id = Integer.parseInt(request.getParameter("cust_id"));
		System.out.println(id);
		
		String password = request.getParameter("pwd1");
		System.out.println(password);
		System.out.println(id + "from " + getClass());
		System.out.println(password + "from " + getClass());
		boolean validCustomer = new CustomerOperations().checkValidUser(id, password, request);
		if (validCustomer) {
			try {
				response.sendRedirect("cust_homePage.jsp");
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			try {
				response.sendRedirect("errorMsg.jsp");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}
