package com.farmerswebmarketing.commands;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.farmerswebmarketing.beans.CustomerBean;
import com.farmerswebmarketing.daos.CustomerOperations;
import com.farmerswebmarketing.interfaces.Command;

public class CustomerSignUpCommand implements Command {

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp) {
		doPost(req, resp);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) {

		int cust_id = Integer.parseInt(request.getParameter("cust_id"));
		String customer_name = request.getParameter("name");
		String pwd = request.getParameter("pwd1");
		long mobile = Long.parseLong(request.getParameter("mobile"));
		String h_no = request.getParameter("house_no");
		String village = request.getParameter("village");
		String mandal = request.getParameter("mandal");
		String district = request.getParameter("district");
		String state = request.getParameter("state");
		int pincode = Integer.parseInt(request.getParameter("pincode"));

		CustomerBean customerBean = new CustomerBean(cust_id, customer_name, mobile, pwd, h_no, village, mandal,
				district, state, pincode);
		int customer = 0;
		try {
			customer = new CustomerOperations().insertCustomer(customerBean);
		} catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		if (customer > 0) {
			try {
				response.sendRedirect("CustomerLogin.jsp");
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			try {
				response.sendRedirect("customer_signup.jsp");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}
