package com.farmerswebmarketing.commands;

public class FarmerLoginCommand {

}
