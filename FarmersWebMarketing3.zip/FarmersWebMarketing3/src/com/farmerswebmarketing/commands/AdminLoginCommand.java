package com.farmerswebmarketing.commands;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.farmerswebmarketing.beans.AdminBean;
import com.farmerswebmarketing.daos.AdminOperations;
import com.farmerswebmarketing.interfaces.AdminDao;
import com.farmerswebmarketing.interfaces.Command;

public class AdminLoginCommand implements Command {

	String username = null;
	String password = null;

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);

	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

		username = request.getParameter("adminusername");
		password = request.getParameter("adminpassword");

		AdminBean adminDetails = new AdminBean();
		adminDetails.setUsername(username);
		adminDetails.setPassword(password);

		try {
			AdminDao dao = new AdminOperations();

			if (dao.checkValidAdmin(username, password)) {
				response.sendRedirect("AdminHome.jsp");
			} else {
				response.sendRedirect("AdminLogin.html");
			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
