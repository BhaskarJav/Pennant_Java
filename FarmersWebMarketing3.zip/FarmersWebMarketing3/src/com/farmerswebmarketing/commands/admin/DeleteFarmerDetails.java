package com.farmerswebmarketing.commands.admin;

import java.io.IOException;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.farmerswebmarketing.beans.FarmerBean;
import com.farmerswebmarketing.daos.AdminOperations;
import com.farmerswebmarketing.interfaces.AdminDao;
import com.farmerswebmarketing.interfaces.Command;

public class DeleteFarmerDetails implements Command{

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
		
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
	

		FarmerBean farmerBean=new FarmerBean();
		
		
		try {
			AdminDao dao=new AdminOperations();
			
			List<FarmerBean> farmerDetails = dao.getFarmerDetails();
		
			
			request.setAttribute("details", farmerDetails);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/deleteById.jsp");

			dispatcher.forward(request, response);
			
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
