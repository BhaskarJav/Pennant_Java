package com.farmerswebmarketing.commands.admin;

import java.io.IOException;

import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.farmerswebmarketing.daos.AdminOperations;
import com.farmerswebmarketing.interfaces.AdminDao;
import com.farmerswebmarketing.interfaces.Command;

public class DeleteFarmerById implements Command{

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
		
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {


		int id = Integer.parseInt(request.getParameter("Preperence"));
		System.out.println(id);
		
		try {
			AdminDao dao = new AdminOperations();

			int deleteFarmerById = dao.deleteFarmerById(id);

			System.out.println("rsfhewb");
			if (deleteFarmerById >0 ) {
				//System.out.println("Deleted");
				response.sendRedirect("FrontController?url=RetrieveFarmer");
			} else {

				response.sendRedirect("deleteById.jsp");
			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
