package com.farmerswebmarketing.commands.farmer;

import java.io.IOException;

import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.farmerswebmarketing.beans.ProductsBean;
import com.farmerswebmarketing.daos.ProductOperations;
import com.farmerswebmarketing.interfaces.Command;
import com.farmerswebmarketing.interfaces.ProductDao;

public class ProductDeleteById implements Command{

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
		
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
int selectedId = Integer.parseInt(request.getParameter("Preperence"));
		
		ProductsBean productsBean=new ProductsBean();
		productsBean.setProduct_id(selectedId);
		
		ProductDao dao;
		try {
			dao = new ProductOperations();
			
			int removeProduct = dao.removeProduct(selectedId);
			

				if (removeProduct>0 ) {
					//System.out.println("Deleted");
					response.sendRedirect("FrontController?url=RetrieveProducts");
				} else {

					response.sendRedirect("deleteproByid.jsp");
				}

			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		
	}

}
