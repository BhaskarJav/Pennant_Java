package com.farmerswebmarketing.commands.farmer;

import java.io.IOException;

import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.farmerswebmarketing.daos.ProductOperations;
import com.farmerswebmarketing.interfaces.Command;
import com.farmerswebmarketing.interfaces.ProductDao;

public class RetrievingImage implements Command {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);

	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

		int id = Integer.parseInt(request.getParameter("id"));
		System.out.println(id);

		try {
			ProductDao dao = new ProductOperations();

		 dao.getPhotoById(id,response,request);
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
