package com.farmerswebmarketing.commands.farmer;

import java.io.IOException;

import java.io.InputStream;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.farmerswebmarketing.beans.ProductsBean;
import com.farmerswebmarketing.daos.ProductOperations;
import com.farmerswebmarketing.interfaces.Command;
import com.farmerswebmarketing.interfaces.ProductDao;

@MultipartConfig
public class ProductsInsert implements Command {

	int pId;
	String name = null;
	int quantity;
	double price;

	int fId;

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);

	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		response.setContentType("text/html;charset=UTF-8");
		System.out.println("fuyhesagfiu");

		pId = Integer.parseInt(request.getParameter("productid"));
		name = request.getParameter("productname");
		quantity = Integer.parseInt(request.getParameter("quantity"));
		price = Double.parseDouble(request.getParameter("price"));
		System.out.println(price);
		Part file = request.getPart("Image");
		
		
		InputStream inputStream = null; 
		 if (file != null) {
             // prints out some information for debugging
             System.out.println(file.getName());
             System.out.println(file.getSize());
             System.out.println(file.getContentType());
               
             // obtains input stream of the upload file
             inputStream = file.getInputStream();
         }
          
	
		fId = Integer.parseInt(request.getParameter("farmerid"));

		ProductsBean productsBean = new ProductsBean();
		productsBean.setProduct_id(pId);
		productsBean.setProduct_name(name);
		productsBean.setQuantity(quantity);
		productsBean.setPrice(price);
		productsBean.setProduct_image(file);
		productsBean.setFarmer_id(fId);

		ProductDao dao;
		try {
			dao = new ProductOperations();

			int addProduct = dao.addProduct(productsBean);

			if (addProduct > 0) {
				response.sendRedirect("ProductHome.jsp");
			} else {
				response.sendRedirect("ProductInsert.jsp");
			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
