package com.farmerswebmarketing.commands.farmer;

import java.io.IOException;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.farmerswebmarketing.beans.FarmerBean;
import com.farmerswebmarketing.daos.FarmerDaoImpl;
import com.farmerswebmarketing.interfaces.Command;
import com.farmerswebmarketing.interfaces.FarmerDao;

public class FarmerRegistrtionClass implements Command{

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request, response);
		
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		int farmerId=Integer.parseInt(request.getParameter("farmerid"));
		System.out.println(farmerId);
		String farmerName=request.getParameter("farmername");
	long phoneNumber = Long.parseLong(request.getParameter("phonenumber"));
		String houseNumber=request.getParameter("housenumber");
		String village=request.getParameter("village");
		String mandal=request.getParameter("mandal");
		String district=request.getParameter("district");
		String state=request.getParameter("state");
		int pincode=Integer.parseInt(request.getParameter("pincode"));
		String password=request.getParameter("password");
		
		
		FarmerBean fbc=new FarmerBean();
		fbc.setFarmer_id(farmerId);
		fbc.setFarmer_name(farmerName);
		fbc.setFarmer_phone_no(phoneNumber);
		fbc.setHouse_no(houseNumber);
		fbc.setVillage(village);
		fbc.setMandal(mandal);
		fbc.setDistrict(district);
		fbc.setState(state);
		fbc.setPincode(pincode);
		fbc.setFarmer_password(password);
		
		
		
		FarmerDao fldi=new FarmerDaoImpl();
		if(fldi.insertFarmer(fbc)>0){
			try {
				response.sendRedirect("FarmerLogin.jsp");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else{
			try {
				response.sendRedirect("home.jsp");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
				
		
	}

	

}
