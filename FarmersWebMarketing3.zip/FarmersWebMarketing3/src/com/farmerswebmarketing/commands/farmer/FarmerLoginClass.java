package com.farmerswebmarketing.commands.farmer;

import java.io.IOException;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.farmerswebmarketing.beans.FarmerBean;
import com.farmerswebmarketing.daos.FarmerDaoImpl;
import com.farmerswebmarketing.interfaces.Command;
import com.farmerswebmarketing.interfaces.FarmerDao;

public class FarmerLoginClass implements Command {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request, response);
		
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		int farmerId=Integer.parseInt(request.getParameter("farmerId"));
		System.out.println(farmerId);
		String password=request.getParameter("password");
		System.out.println(password);
		
		
		FarmerBean fbc=new FarmerBean();
		fbc.setFarmer_id(farmerId);
		fbc.setFarmer_password(password);
		
		
		FarmerDao fldi=new FarmerDaoImpl();
		if(fldi.checkValidFarmer(farmerId, password)){
			try {
				response.sendRedirect("ProductHome.jsp");
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		}else{
			try {
				response.sendRedirect("FarmerLogin.jsp");
			} catch (IOException e) {
				
				e.printStackTrace();
			};
		}
		
		
		
	}

}
